## nhanesCodeMapExamination

MeasureStatus   <- list('1'='Complete', '2'='Partial', '3'='Not done')
MeasureComment  <- list('0'='None', '1'='Safety exclusion', '2'='SP refusal', '3'='No time', '4'='Physical limitation', 
                        '5'='Communication problem', '6'='Equipment failure', '7'='SP ill/emergency', 
                        '56'='Came late/left early', '84'='SP with child', '99'='Other, specify', '122'='Language barrier') 
YesNo           <- list('1'='Yes', '2'='No')
YesNoRefused    <- list('1'='Yes', '2'='No', '7'='Refused', '9'="Don't know")
YesNoCheckBox   <- list('1'='Yes (checkbox checked)', '2'='No (checkbox unchecked)', '9'="Don't know")
BParm           <- list('1'='Right','2'='Left','8'='Could not obtain')
BPcuffsize      <- list('1'='Infant (6X12)','2'='Child (9X17)','3'='Adult (12X22)','4'='Large (15X32)','5'='Thigh (18X35)')
PulseRegularity <- list('1'='Regular', '2'='Irregular')
PulseType       <- list('1'='Radial','2'='Brachial','8'='Could not obtain')
YesNoObtain     <- list('1'='Yes', '2'='No', '8'='Could not obtain')
MeasureStats    <- list('1'='Complete data for age group', '2'='Partial: Height and weight obtained', 
                        '3'='Other partial exam', '4'='No body measures exam data')
RecLengthHtDiff <- list('1'='Difference between recumbent length and standing height was greater than 2.5 cm')
UnusualValue    <- list('1'='Unusual value noted during data review')
BMIcomment      <- list('1'='Could not obtain', '2'='Exceeds capacity', '3'='Clothing', '4'='Medical appliance')
RecumComment    <- list('1'='Could not obtain', '2'='Exceeds capacity', '3'='Not straight')
CouldNotObtain  <- list('1'='Could not obtain')
ObtainExceeds   <- list('1'='Could not obtain', '2'='Exceeds capacity', '3'='Hard to obtain')
ArmLocation     <- list('1'='Above elbow', '2'='Below elbow')
LegLocation     <- list('1'='Above knee',  '2'='Below knee')
Exhalation      <- list('1'='Acceptable measurement', '2'='Could Not Obtain', '3'='< 5 ppb', '4'='> 300 ppb')
WhyExamsNotDone <- list('1'='Safety exclusion', '2'='SP refusal', '3'='No time', '4'='Physical limitation', 
                        '5'='Communication problem', '6'='Equipment failure', '7'='SP ill/emergency', 
                        '14'='Interrupted', '56'='Came late/left early', '84'='SP with child', '99'='Other')
RightLeft       <- list('1'='Right', '2'='Left')
GripStrength    <- list('1'='Maximal', '2'='Questionable')
GripTestStatus  <- list('1'='Completed test on both hands', '2'='Completed test on only one hand', '3'='Did not perform test')
DominantHand    <- list('1'='Right-handed', '2'='Left-handed', '3'='Use both hands equally', '7'='Refused', '9'="Don't know")
ToothPresent    <- list('1'='Primary tooth (deciduous) present', '2'='Permanent tooth present', '3'='Dental implant', 
                        '4'='Tooth not present','5'='Permanent dental root fragment present', '9'='Could not assess')
CoronalCaries   <- list('D'='Sound primary tooth', 'E'='Missing due to dental disease', 
                        'J'='Permanent root tip is present but a restorative replacement is present', 
                        'K'='Primary tooth with surface condition (s)', 'M'='Missing due to other causes', 
                        'P'='Missing due to dental disease but replaced by a removable restoration', 
                        'Q'='Missing due to other causes but replaced by a removable restoration', 
                        'R'='Missing due to dental disease, but replaced by a fixed restoration', 
                        'S'='Sound permanent tooth', 'T'='Permanent root tip is present but no restorative replacement is present',
                        'U'='Unerupted','X'='Missing due to other causes, but replaced by a fixed restoration', 
                        'Y'='Tooth present, condition cannot be assessed', 'Z'='Permanent tooth with surface condition (s)')
CoronalSurface  <- list('0'='Lingual surface caries','1'='Occlusal/incisal caries','2'='Facial surface caries', '3'='Mesial caries',
                        '4'='Distal caries','5'='Lingual surface restoration','6'='Occlusal/incisal restoration',
                        '7'='Facial surface restoration','8'='Mesial restoration','9'='Distal restoration')
DentalSealant   <- list('0'='Sealant not present', '1'='Occlusal sealant on permanent tooth', '2'='Facial sealant on permanent tooth',
                        '3'='Lingual sealant on permanent tooth', '4'='Occlusal sealant on primary tooth', '9'='Cannot be assessed')
Fluorosis       <- list('0'='Normal', '1'='Very mild', '2'='Mild', '3'='Moderate', '4'='Severe', '5'='Questionable', '8'='Non-fluoride opacities', '9'='Cannot be assessed')
FirstTestStatus <- list('1'='Complete Exam', '2'='Partial Exam', '3'='Not Done', '4'='Safety Exclusion')
PresentAbsent   <- list('1'='Present', '2'='Absent', '8'='Could not obtain')

nhanesCodeMapExamination <- list()
nhanesCodeMapExamination[['ARDEXSTS']]  <- 'MeasureStatus'
nhanesCodeMapExamination[['AUAEXSTS']]  <- 'MeasureStatus'
nhanesCodeMapExamination[['AUQ020']]    <- 'YesNoRefused'
nhanesCodeMapExamination[['AUQ020A']]   <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUQ020B']]   <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUQ020C']]   <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUQ020D']]   <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUQ020E']]   <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUQ030']]    <- 'YesNoRefused'
nhanesCodeMapExamination[['AUXOTSPL']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXLOEXC']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXLOIMC']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXLOCOL']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXLOABN']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXROTSP']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXROEXC']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXROIMC']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXROCOL']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUXROABN']]  <- 'YesNoCheckBox'
nhanesCodeMapExamination[['AUAEAR']]    <- 'RightLeft'


#BPX BLOOD PRESSURE SECTION-----------------------------
nhanesCodeMapExamination <- list()
nhanesCodeMapExamination[['PEASCST1']] <- 'MeasureStatus'
nhanesCodeMapExamination[['PEASCCT1']] <- 'MeasureComment'
nhanesCodeMapExamination[['BPQ150A']]  <- 'YesNo'
nhanesCodeMapExamination[['BPQ150B']]  <- 'YesNo'
nhanesCodeMapExamination[['BPQ150C']]  <- 'YesNo'
nhanesCodeMapExamination[['BPQ150D']]  <- 'YesNo'
nhanesCodeMapExamination[['BPAARM']]   <- 'BParm'
nhanesCodeMapExamination[['BPACSZ']]   <- 'BPcuffsize'
nhanesCodeMapExamination[['BPXPULS']]  <- 'PulseRegularity'
nhanesCodeMapExamination[['BPXPTY']]   <- 'PulseType'
nhanesCodeMapExamination[['BPAEN1']]   <- 'YesNoObtain'
nhanesCodeMapExamination[['BPAEN2']]   <- 'YesNoObtain'
nhanesCodeMapExamination[['BPAEN3']]   <- 'YesNoObtain'
nhanesCodeMapExamination[['BPAEN4']]   <- 'YesNoObtain'

#BMX BODY MEASURES SECTION-----------------------------
nhanesCodeMapExamination[['BMAEXTS']]  <- 'MeasureStatus'
nhanesCodeMapExamination[['BMAEXCMT']] <- 'MeasureComment'
nhanesCodeMapExamination[['BMDSTATS']] <- 'MeasureStats'
nhanesCodeMapExamination[['BMDRECUF']] <- 'RecLengthHtDiff'
nhanesCodeMapExamination[['BMDSUBF']]  <- 'UnusualValue'
nhanesCodeMapExamination[['BMDTHICF']] <- 'UnusualValue'
nhanesCodeMapExamination[['BMDLEGF']]  <- 'UnusualValue'
nhanesCodeMapExamination[['BMDARMLF']] <- 'UnusualValue'
nhanesCodeMapExamination[['BMDCALFF']] <- 'UnusualValue'
nhanesCodeMapExamination[['BMIWT']]    <- 'BMIcomment'
nhanesCodeMapExamination[['BMIRECUM']] <- 'RecumComment'
nhanesCodeMapExamination[['BMIHEAD']]  <- 'RecumComment'
nhanesCodeMapExamination[['BMIHT']]    <- 'RecumComment'
nhanesCodeMapExamination[['BMILEG']]   <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMICALF']]  <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMIARML']]  <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMIARMC']]  <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMIWAIST']] <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMITHICR']] <- 'CouldNotObtain'
nhanesCodeMapExamination[['BMITRI']]   <- 'ObtainExceeds'
nhanesCodeMapExamination[['BMISUB']]   <- 'ObtainExceeds'
nhanesCodeMapExamination[['BPAAMP']]   <- 'YesNo'
nhanesCodeMapExamination[['BPAUREXT']] <- 'YesNoObtain'
nhanesCodeMapExamination[['BPAUPREL']] <- 'ArmLocation'
nhanesCodeMapExamination[['BPAULEXT']] <- 'YesNoObtain'
nhanesCodeMapExamination[['BPAUPLEL']] <- 'ArmLocation'
nhanesCodeMapExamination[['BMALOREX']] <- 'YesNoObtain'
nhanesCodeMapExamination[['BMALORKN']] <- 'LegLocation'
nhanesCodeMapExamination[['BMALLEXT']] <- 'YesNoObtain'
nhanesCodeMapExamination[['BMALLKNE']] <- 'LegLocation'

nhanesCodeMapExamination[['ENQ010']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ020']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ040']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ050']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ060']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ070']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ080']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ090']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENQ100']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['ENXCMT']]   <- 'WhyExamsNotDone'
nhanesCodeMapExamination[['ENXTR1G']]  <- 'Exhalation'
nhanesCodeMapExamination[['ENXTR2G']]  <- 'Exhalation'
nhanesCodeMapExamination[['ENXTR3G']]  <- 'Exhalation'
nhanesCodeMapExamination[['ENXTR4G']]  <- 'Exhalation'

nhanesCodeMapExamination[['MGDEXSTS']] <- 'GripTestStatus'
nhanesCodeMapExamination[['MGD050']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD070']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD080']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD090']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD100']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD110']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD120']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['MGD130']]   <- 'DominantHand'
nhanesCodeMapExamination[['MGAPHAND']] <- 'RightLeft'
nhanesCodeMapExamination[['MGATHAND']] <- 'RightLeft'
nhanesCodeMapExamination[['MGXH1T1E']] <- 'GripStrength'
nhanesCodeMapExamination[['MGXH1T2E']] <- 'GripStrength'
nhanesCodeMapExamination[['MGXH1T3E']] <- 'GripStrength'
nhanesCodeMapExamination[['MGXH2T1E']] <- 'GripStrength'
nhanesCodeMapExamination[['MGXH2T2E']] <- 'GripStrength'
nhanesCodeMapExamination[['MGXH2T3E']] <- 'GripStrength'

nhanesCodeMapExamination[['OHDEXSTS']] <- 'MeasureStatus'
nhanesCodeMapExamination[['OHDDESTS']] <- 'MeasureStatus'
nhanesCodeMapExamination[['OHXIMP']]   <- 'YesNo'
nhanesCodeMapExamination[['OHX01TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX02TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX03TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX04TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX05TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX06TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX07TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX08TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX09TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX10TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX11TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX12TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX13TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX14TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX15TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX16TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX17TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX18TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX19TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX20TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX21TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX22TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX23TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX24TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX25TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX26TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX27TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX28TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX29TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX30TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX31TC']]  <- 'ToothPresent'
nhanesCodeMapExamination[['OHX32TC']]  <- 'ToothPresent'

nhanesCodeMapExamination[['OHX02CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX03CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX04CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX05CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX06CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX07CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX08CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX09CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX10CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX11CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX12CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX13CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX14CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX15CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX16CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX17CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX18CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX19CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX20CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX21CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX22CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX23CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX24CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX25CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX26CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX27CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX28CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX29CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX30CTC']] <- 'CoronalCaries'
nhanesCodeMapExamination[['OHX31CTC']] <- 'CoronalCaries'

nhanesCodeMapExamination[['OHX02CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX03CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX04CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX05CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX06CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX07CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX08CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX09CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX10CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX11CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX12CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX13CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX14CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX15CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX16CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX17CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX18CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX19CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX20CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX21CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX22CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX23CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX24CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX25CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX26CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX27CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX28CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX29CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX30CSC']] <- 'CoronalSurface'
nhanesCodeMapExamination[['OHX31CSC']] <- 'CoronalSurface'

nhanesCodeMapExamination[['OHX02SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX03SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX04SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX05SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX07SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX10SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX12SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX13SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX14SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX15SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX18SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX19SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX20SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX21SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX28SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX29SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX30SE']]  <- 'DentalSealant'
nhanesCodeMapExamination[['OHX31SE']]  <- 'DentalSealant'

nhanesCodeMapExamination[['OHX02DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX03DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX04DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX05DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX06DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX07DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX08DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX09DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX10DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX11DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX12DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX13DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX14DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX15DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX18DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX19DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX20DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX21DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX22DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX23DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX24DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX25DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX26DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX27DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX28DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX29DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX30DI']]  <- 'Fluorosis'
nhanesCodeMapExamination[['OHX31DI']]  <- 'Fluorosis'

nhanesCodeMapExamination[['OHDEXSTS']] <- 'MeasureStatus'
nhanesCodeMapExamination[['OHDRCSTS']] <- 'MeasureStatus'
nhanesCodeMapExamination[['OHAROCDT']] <- 'YesNo'
nhanesCodeMapExamination[['OHAROCGP']] <- 'YesNo'
nhanesCodeMapExamination[['OHAROCOH']] <- 'YesNo'
nhanesCodeMapExamination[['OHAROCCI']] <- 'YesNo'
nhanesCodeMapExamination[['OHAROCDE']] <- 'YesNo'
nhanesCodeMapExamination[['OHARNF']]   <- 'YesNo'
nhanesCodeMapExamination[['OHAROTH']]  <- 'YesNo'
nhanesCodeMapExamination[['OHAPOS']]   <- 'YesNo'

nhanesCodeMapExamination[['SPQ010']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ020']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ030']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ040']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ050']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ060']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ080']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ090']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPQ100']]   <- 'YesNoRefused'
nhanesCodeMapExamination[['SPXNSTAT']] <- 'FirstTestStatus'
nhanesCodeMapExamination[['SPDBRONC']] <- 'YesNo'
nhanesCodeMapExamination[['SPXBSTAT']] <- 'FirstTestStatus'

nhanesCodeMapExamination[['SPAPLAT']]  <- 'YesNo'
nhanesCodeMapExamination[['SPAACC']]   <- 'YesNo'
nhanesCodeMapExamination[['TBQ070']]   <- 'YesNo'
nhanesCodeMapExamination[['TBXRUVES']] <- 'PresentAbsent'
nhanesCodeMapExamination[['TBXRUULC']] <- 'PresentAbsent'

