
Language            <- list('1'='English', '8'='Spanish', '9'='Other', '77'='Refused', '99'="Don't know")
SpanishEnglish      <- list('1'='Only Spanish','2'='More Spanish than English','3'='Both Equally',
                            '4'='More English than Spanish','5'='Only English','7'='Refused','9'="Don't know")
AsianEnglish        <- list('1'='Only Non-English language','2'='More Non-English than English','3'='Both Equally',
                            '4'='More English than Non-English','5'='Only English','7'='Refused','9'="Don't know")
AgeOfFirstDrink     <- list('1'='I have never had a drink of alcohol, other than a few sips', '2'='8 years old or younger',
                            '3'='9 or 10 years old', '4'='11 or 12 years old', '5'='13 or 14 years old', '6'='15 or 16 years old', 
                            '7'='17 years old or older', '77'='Refused', '99'="Don't know")
DaysDrankLifetime   <- list('1'='0 days', '2'='1 or 2 days', '3'='3 to 9 days', '4'='10 to 19 days', '5'='20 to 39 days',
                            '6'='40 to 99 days', '7'='100 or more days', '77'='Refused', '99'="Don't know")
DaysDrank30days     <- list('1'='0 days', '2'='1 or 2 days', '3'='3 to 5 days', '4'='6 to 9 days', '5'='10 to 19 days',
                            '6'='20 to 29 days', '7'='All 30 days', '77'='Refused', '99'="Don't know")
DaysDrank5orMore30  <- list('1'='0 days', '2'='1 day', '3'='2 days', '4'='3 to 5 days', '5'='6 to 9 days', '6'='10 to 19 days',
                            '7'='20 or more days', '77'='Refused', '99'="Don't know")
YesNo               <- list('1'='Yes', '2'='No')
YesNoRefused        <- list('1'='Yes', '2'='No', '7'='Refused', '9'="Don't know")
YesNoUnable         <- list('1'='Yes', '2'='No', '3'='Unable to do activity', '7'='Refused', '9'="Don't know")
YesNoNeverWork      <- list('1'='Yes', '2'='No', '3'='Never Worked', '7'='Refused', '9'="Don't know")
YesNoNeverWalk      <- list('1'='Yes', '2'='No', '3'='Never walks uphill or hurries', '7'='Refused', '9'="Don't know")
YesNoBrdrline       <- list('1'='Yes', '2'='No', '3'='Borderline', '7'='Refused', '9'="Don't know")
Duration            <- list('1'='Week', '2'='Month', '3'='Year', '7'='Refused', '9'="Don't know")
Pet                 <- list('1'='Dog', '2'='Cat', '3'='Small furry animal', '7'='Refused', '9'="Don't know")
Season              <- list('1'='Spring', '2'='Summer', '3'='Fall', '4'='Winter', '7'='Refused', '9'="Don't know")
HearingQuality      <- list('1'='Excellent', '2'='Good', '3'='A little trouble', '4'='Moderate hearing trouble', 
                            '5'='A lot of trouble', '6'='Deaf', '7'='Refused', '9'="Don't know")
HearingQuality2     <- list('1'='Good', '2'='Little trouble', '3'='Lot of trouble', '4'='Deaf', '7'='Refused', '9'="Don't know")
HearingAid          <- list('1'='Hearing aid','2'='Cochlear implant','3'='Both hearing aid and cochlear implant','7'='Refused','9'="Don't know")
EventTime           <- list('1'='Less than a year ago', '2'='1 year to 4 years ago', '3'='5 to 9 years ago',
                            '4'='Ten or more years ago', '5'='Never', '7'='Refused', '9'="Don't know")
EventTime1          <- list('1'='Less than a year ago', '2'='1 year to 4 years ago', '3'='More than 4 years ago',
                            '4'='Never', '7'='Refused', '9'="Don't know")
EventTime2          <- list('1'='Less than three months', '2'='Three months to a year', '3'='1 to 4 years', 
                            '4'='5 to 9 years', '5'='Ten or more years', '7'='Refused', '9'="Don't know")
EventTime3          <- list('1'='Less than 1 year ago', '2'='1 year to less than 2 years ago', '3'='2 years to less than 5 years ago',
                            '4'='5 years or more', '7'='Refused', '9'="Don't know")
EventTime4          <- list('1'='1 year ago or less','2'='More than 1 year ago but no more than 2 years ago',
                            '3'='More than 2 years ago but no more than 5 years ago',
                            '4'='More than 5 years ago', '5'='Never', '7'='Refused', '9'="Don't know")
Severity            <- list('1'='No problem', '2'='A small problem', '3'='A moderate problem', 
                            '4'='A big problem', '5'='A very big problem', '7'='Refused', '9'="Don't know")
HowOften            <- list('1'='Most of the time', '2'='Sometimes', '3'='Rarely/seldom', '4'='Never', '7'='Refused', '9'="Don't know")
HowOften2           <- list('1'='Always', '2'='Usually', '3'='About half the time', '4'='Seldom', 
                            '5'='Never', '6'='No noise exposure past 12 months', '7'='Refused', '9'="Don't know")
HowOften3           <- list('1'='Almost always', '2'='At least once a day', '3'='At least once a week', 
                            '4'='At least once a month', '5'='Less frequently than once a month', '7'='Refused', '9'="Don't know")
HowOftenPerMo       <- list('1'='Once per month', '2'='2-3 times per month', '3'='4-8 times per month (about 1-2 times per week)', 
                            '4'='9-24 times per month (about 3-6 times per week)', '5'='25-30 times per month (one or more times per day)',
                            '7'='Refused', '9'="Don't know")
HowOftenInject      <- list('1'='More than once a day', '2'='About once a day', '3'='At least once a week but not every day', 
                            '4'='At least once a month but not every week', '5'='Less than once a month', '7'='Refused', '9'="Don't know")
HowManyPerDay       <- list('1'='1 per day', '2'='2 per day', '3'='3-5 per day',
                            '4'='Six or more per day', '7'='Refused', '9'="Don't know")
HowManyPerYear      <- list('0'='None', '1'='1', '2'='2 to 3', '3'='4 to 9','4'='10 to 12', '5'='13 or more','77'='Refused','99'="Don't know")
HowManyInLife       <- list('1'='Once', '2'='2-5 times', '3'='6-19 times', '4'='20-49 times','5'='50-99 times',
                            '6'='100 times or more','77'='Refused','99'="Don't know")
HowLongAgoTreated   <- list('1'='Less than 1 year ago', '2'='1 to 5 years ago', '3'='5 years or more ago', '7'='Refused', '9'="Don't know")
HowLong             <- list('1'='Less than 3 months', '2'='3 to 11 months', '3'='1 to 2 years', '4'='3 to 4 years', 
                            '5'='5 to 9 years','6'='10 to 14 years','7'='15 or more years','8'='Not exposed','77'='Refused','99'="Don't know")
HowLong2            <- list('1'='Days', '2'='Weeks', '3'='Months', '4'='Years', '7'='Refused', '9'="Don't know")
HowLongProblem      <- list('1'='Less than 2 weeks', '2'='2 weeks to 3 months', '3'='More than 3 months', '7'='Refused', '9'="Don't know")
HoursPerDay         <- list('0'='Less than 1 hour','1'='1 hour','2'='2 hours','3'='3 hours','4'='4 hours',
                            '5'='5 hours or more','6'='None', '8'='Do not watch TV or videos','77'='Refused','99'="Don't know")
Difficulty          <- list('1'='No difficulty', '2'='Some difficulty', '3'='Much difficulty', '4'='Unable to do',
                            '5'='Do not do this activity', '7'='Refused', '9'="Don't know")
Difficulty2         <- list('0'='Not at all difficult', '1'='Somewhat difficult', '2'='Very difficult',
                            '3'='Extremely difficult', '7'='Refused', '9'="Don't know")
RoundsFired         <- list('1'='1 to less than 100 rounds', '2'='100 to less than 1000 rounds', '3'='1000 to less than 10,000 rounds', 
                            '4'='10,000 to less than 50,000 rounds', '5'='50,000 rounds or more', '7'='Refused', '9'="Don't know")
ChangeOfPace        <- list('1'='Stop or slow down', '2'='Continue at the same pace', '7'='Refused', '9'="Don't know")
Relieved            <- list('1'='Relieved', '2'='Not Relieved', '7'='Refused', '9'="Don't know")
ReliefTime          <- list('1'='10 minutes or less', '2'='More than 10 minutes', '7'='Refused', '9'="Don't know")
PainLocation        <- list('1'='Pain in right arm', '2'='Pain in right chest','3'='Pain in neck','4'='Pain in upper sternum', 
                            '5'='Pain in lower sternum', '6'='Pain in left chest', '7'='Pain in left arm',
                            '8'='Pain in epigastric area', '77'='Refused', '99'="Don't know")
Condition           <- list('1'='Excellent', '2'='Very good', '3'='Good', '4'='Fair', '5'='Poor', '7'='Refused', '9'="Don't know")
Frequency           <- list('0'='Not at all', '1'='Several days', '2'='More than half the days',
                            '3'='Nearly every day', '7'='Refused', '9'="Don't know")
Frequency2          <- list('1'='Always', '2'='Most of the time','3'='Sometimes', '4'='Rarely', 
                            '5'='Never', '6'="Don't go out in the sun", '77'='Refused', '99'="Don't know")
Frequency3          <- list('1'='Per day', '2'='Per week', '3'='Per month', '4'='Per year')
Frequency4          <- list('1'='Less than once a month', '2'='A few times a month', '3'='A few times a week', 
                            '4'='Every day and/or night', '7'='Refused', '9'="Don't know")
LeakageFreq         <- list('1'='Never', '2'='Less than once a month', '3'='A few times a month', '4'='A few times a week', 
                            '5'='Every day and/or night', '7'='Refused', '9'="Don't know")
SkinReaction        <- list('1'='Get a severe sunburn with blisters', '2'='A severe sunburn for a few days with peeling', 
                            '3'='Mildly burned with some tanning', '4'='Turning darker without a sunburn', 
                            '5'='Nothing would happen in half an hour', '6'='Other', '77'='Refused', '99'="Don't know")
A1Clevel            <- list('1'='Less than 6', '2'='Less than 7', '3'='Less than 8', '4'='Less than 9', '5'='Less than 10', 
                            '6'='Provider did not specify goal', '77'='Refused', '99'="Don't know")
LastDilation        <- list('1'='Less than 1 month', '2'='1-12 months', '3'='13-24 months',
                            '4'='Greater than 2 years', '5'='Never', '7'='Refused', '9'="Don't know")
DrugsInjected       <- list('1'='Cocaine', '2'='Heroin', '3'='Methamphetamine', '4'='Steroids',
                            '5'='Any other drugs', '7'='Refused', '9'="Don't know")
BirthWeight5p5      <- list('1'='More than 5-1/2 lbs. (2500 g)', '2'='Less than 5-1/2 lbs. (2500 g)', '7'='Refused', '9'="Don't know")
BirthWeight9        <- list('1'='More than 9 lbs. (4100 g)', '2'='Less than 9 lbs. (4100 g)', '7'='Refused', '9'="Don't know")
JudgeWeight         <- list('1'='Overweight', '2'='Underweight', '3'='About the right weight', '7'='Refused', '9'="Don't know")
HealthInsure        <- list('14'='Covered by private insurance', '15'='Covered by Medicare', '16'='Covered by Medi-Gap',
                            '17'='Covered by Medicaid', '18'='Covered by SCHIP', '19'='Covered by military health care',
                            '20'='Covered by Indian Health Service', '21'='Covered by state-sponsored health plan',
                            '22'='Covered by other government insurance','23'='Covered by single service plan','40'='No coverage of any type')
Comparison          <- list('1'='Better', '2'='Worse', '3'='About the same', '7'='Refused', '9'="Don't know")
RoutinePlace        <- list('1'='Yes', '2'='There is no place', '3'='There is more than one place', '7'='Refused', '9'="Don't know")
CareVisitPlace      <- list('1'='Clinic or health center', '2'="Doctor's office or HMO", '3'='Hospital emergency room',
                            '4'='Hospital outpatient department', '5'='Some other place', '7'='Refused', '9'="Don't know")
TimeSinceVisit      <- list('1'='6 months or less', '2'='More than 6 months, but not more than 1 year ago', 
                            '3'='More than 1 year, but not more than 3 years ago', '4'='More than 3 years', 
                            '5'='Never', '7'='Refused', '9'="Don't know")
TimeSinceBPReading  <- list('1'='Less than 6 months ago', '2'='6 months to 1 year ago', '3'='More than 1 year to 2 years ago', 
                            '4'='More than 2 years ago', '5'='Never', '7'='Refused', '9'="Don't know")
HomeOwnOrRent       <- list('1'='Owned or being bought', '2'='Rented', '3'='Other arrangement', '7'='Refused', '9'="Don't know")
HepAVaccine         <- list('1'='Yes, at least 2 doses', '2'='Less than 2 doses', '3'='No doses', '7'='Refused', '9'="Don't know")
HepBVaccine         <- list('1'='Yes, at least 3 doses', '2'='Less than 3 doses', '3'='No doses', '7'='Refused', '9'="Don't know")
HPVVaccine          <- list('1'='Cervarix', '2'='Gardasil', '3'='Both', '7'='Refused', '9'="Don't know")
DosesReceived       <- list('1'='1 Dose', '2'='2 Doses', '3'='3 Doses', '7'='Refused', '9'="Don't know")
UrineLoss           <- list('1'='Drops', '2'='Small splashes', '3'='More', '7'='Refused', '9'="Don't know")
BotheredBy          <- list('1'='Not at all','2'='Only a little','3'='Somewhat','4'='Very much','5'='Greatly','7'='Refused','9'="Don't know")
ArthritisType       <- list('1'='Osteoarthritis or degenerative arthritis', '2'='Rheumatoid arthritis', 
                            '3'='Psoriatic arthritis', '4'='Other', '7'='Refused', '9'="Don't know")
KindOfCancer        <- list('10'='Bladder', '11'='Blood', '12'='Bone', '13'='Brain', '14'='Breast',
                            '15'='Cervix (cervical)','16'='Colon','17'='Esophagus (esophageal)',
                            '18'='Gallbladder','19'='Kidney','20'='Larynx/ windpipe','21'='Leukemia','22'='Liver',
                            '23'='Lung','24'="Lymphoma/ Hodgkin's disease",'25'='Melanoma','26'='Mouth/tongue/lip',
                            '27'='Nervous system','28'='Ovary (ovarian)','29'='Pancreas (pancreatic)','30'='Prostate',
                            '31'='Rectum (rectal)','32'='Skin (non-melanoma)','33'="Skin (don't know what kind)",
                            '34'='Soft tissue (muscle or fat)','35'='Stomach','36'='Testis (testicular)','37'='Thyroid',
                            '38'='Uterus (uterine)','39'='Other','66'='More than 3 kinds','77'='Refused','99'="Don't know")
RememberFreq        <- list('0'='Never', '1'='About once', '2'='Two or three times', '3'='Nearly every day', 
                            '4'='Several times a day', '7'='Refused', '9'="Don't know")
WorkStatus          <- list('1'='Working at a job or business', '2'='With a job or business but not at work', 
                            '3'='Looking for work', '4'='Not working at a job or business', '7'='Refused', '9'="Don't know")
WorkSituation       <- list('1'='An employee of a private company, business, or individual for wages, salary, or commission.',
                            '2'='A federal government employee','3'='A state government employee','4'='A local government employee',
                            '5'='Self-employed in own business, professional practice or farm.',
                            '6'='Working without pay in family business or farm','77'='Refused','99'="Don't know")
NotWorkReason       <- list('1'='Taking care of house or family', '2'='Going to school', 
                            '3'='Retired', '4'='Unable to work for health reasons', '5'='On layoff', 
                            '6'='Disabled', '7'='Other', '77'='Refused','99'="Don't know")
DentalVisit         <- list('1'='6 months or less','2'='More than 6 months, but not more than 1 year ago','3'='More than 1 year, but not more than 2 years ago',
                            '4'='More than 2 years, but not more than 3 years ago','5'='More than 3 years, but not more than 5 years ago',
                            '6'='More than 5 years ago','7'='Never have been', '77'='Refused','99'="Don't know")
DentalVisitReason   <- list('1'='Went in on own for check-up, examination, or cleaning','2'='Was called in by the dentist for check-up, examination, or cleaning',
                            '3'='Something was wrong, bothering or hurting','4'='Went for treatment of a condition that dentist discovered at earlier checkup or examination',
                            '5'='Other', '7'='Refused', '9'="Don't know")
NoDentalVisitReason <- list('10'='Could not afford the cost','11'='Did not want to spend the money', '12'='Insurance did not cover recommended procedure',
                            '13'='Dental office is too far away', '14'='Dental office not open at convenient time','15'='Another dentist recommended not doing it', 
                            '16'='Afraid or do not like dentists', '17'='Unable to take time off from work', '18'='Too busy',
                            '19'='I did not think anything serious was wrong - expected dental problems to go away', '20'='Other', '77'='Refused','99'="Don't know")
DentalComplaints    <- list('1'='Very often', '2'='Fairly often', '3'='Occasionally', '4'='Hardly ever', '5'='Never', '7'='Refused', '9'="Don't know")
OralCancerExam      <- list('1'='Within past year', '2'='Between 1 and 3 years ago', '3'='Over 3 years ago', '7'='Refused', '9'="Don't know")
OralExamPro         <- list('1'='Doctor/physician', '2'='Nurse/nurse practitioner', '3'='Dentist (include oral surgeons)',
                            '4'='Dental Hygienist', '5'='Other', '7'='Refused', '9'="Don't know")
WheezingPerWeek     <- list('0'='Never', '1'='1 or more nights per week', '2'='Less than 1 night per week', '7'='Refused', '9'="Don't know")
LimitedByWheezing   <- list('1'='Not at all','2'='A little','3'='A fair amount','4'='A moderate amount','5'='A lot','7'='Refused','9'="Don't know")
DaysLostToWheezing  <- list('0'='None', '1'='1 to 7', '2'='8 to 30', '3'='31 plus', '7'='Refused', '9'="Don't know")
HealthProblems      <- list('10'='Arthritis/rheumatism','11'='Back or neck problem', '12'='Birth defect', '13'='Cancer', 
                            '14'='Depression/anxiety/emotional problem', '15'='Other developmental problem (such as cerebral palsy)',
                            '16'='Diabetes', '17'='Fractures, bone/joint injury','18'='Hearing problem','19'='Heart problem',
                            '20'='Hypertension/high blood pressure','21'='Lung/breathing problem', '22'='Mental retardation','23'='Other injury',
                            '24'='Senility','25'='Stroke problem', '26'='Vision/problem seeing','27'='Weight problem',
                            '28'='Other impairment/problem','77'='Refused','99'="Don't know")
AspirinAdvice       <- list('1'='Yes','2'='No','3'='Sometimes','4'='Stopped aspirin use due to side effects')
PillSchedule        <- list('1'='One every day', '2'='One every other day', '3'='Another schedule', '7'='Refused', '9'="Don't know")
DoseFrequency       <- list('1'='Per day', '2'='Per week')
AgeOfMenarche       <- list('1'='Younger than 10', '2'='10 to 12', '3'='13 to 15', '4'='16 or older', '7'='Refused', '9'="Don't know")
NonRegPeriod        <- list('1'='   Pregnancy','2'='Breast feeding','7'='Menopause/Hysterectomy',
                            '8'='Medical conditions/treatments','9'='Other','77'='Refused','99'="Don't know")
AgeLastPeriod       <- list('1'='Younger than 30','2'='30 to 34','3'='35 to 39','4'='40 to 44','5'='45 to 49',
                            '6'='50 to 54','7'='55 or older','77'='Refused','99'="Don't know")
PregDiabetes        <- list('1'='Yes', '2'='No', '3'='Borderline', '7'='Refused', '9'="Don't know")
TimeUnits           <- list('1'='Months','2'='Years','7'='Refused','9'="Don't know")
HormonePills        <- list('10'='Pills','77'='Refused','99'="Don't know")
HormonePatches      <- list('11'='Patches')
HormoneCream        <- list('12'='Cream/suppository/injection')
OralSexProtection   <- list('1'='Never', '2'='Rarely', '3'='Usually', '4'='Always', '5'='Unsure', '7'='Refused', '9'="Don't know")
VaginalOrAnalSex    <- list('0'='Never', '1'='Once', '2'='2-11 times', '3'='12-51 times', '4'='52-103 times', '5'='104-364 times', '6'='365 times or more', '77'='Refused','99'="Don't know")
SexWithCondom       <- list('1'='Never', '2'='Less than half of the time', '3'='About half of the time', 
                            '4'='Not always, but more than half of the time', '5'='Always','7'='Refused','9'="Don't know")
Circumcised         <- list('1'='Circumcised', '2'='Uncircumcised', '7'='Refused','9'="Don't know")
MSexOrientation     <- list('1'='Heterosexual or straight (attracted to women)', '2'='Homosexual or gay (attracted to men)', 
                            '3'='Bisexual (attracted to men and women)', '4'='Something else', '5'='Not sure', '7'='Refused', '9'="Don't know")
FSexOrientation     <- list('1'='Heterosexual or straight (attracted to men)', '2'='Homosexual or gay (attracted to women)', 
                            '3'='Bisexual (attracted to men and women)', '4'='Something else', '5'='Not sure', '7'='Refused', '9'="Don't know")
SmokingPattern      <- list('1'='Every day', '2'='Some days', '3'='Not at all', '7'='Refused', '9'="Don't know")
SmokeAfterWaking    <- list('1'='Within 5 minutes', '2'='From 6 to 30 minutes', '3'='From more than 30 minutes to one hour', 
                            '4'='More than one hour', '7'='Refused', '9'="Don't know")
YesNoCigarettes     <- list('1'='Yes', '2'='No', '3'='No usual brand', '4'='Rolls own', '7'='Refused', '9'="Don't know")
CigaretteFilter     <- list('0'='Non-filter', '1'='Filter')
MentholIndicator    <- list('0'='Non-menthol', '1'='Menthol')
CigaretteLength     <- list('1'='Regular (68-72 mm)', '2'='King (79-88 mm)', '3'='Long (94-101 mm)', '4'='Ultra long (110-121 mm)')
CigarettesSmoked    <- list('1'='I have never smoked, not even a puff', '2'='1 or more puffs but never a whole cigarette', 
                            '3'='1 cigarette', '4'='2 to 5 cigarettes', '5'='6 to 15 cigarettes', '6'='16 to 25 cigarettes', 
                            '7'='26 to 99 cigarettes', '8'='100 or more cigarettes', '77'='Refused', '99'="Don't know")
CigaretteBrand      <- list('1'='Marlboro', '2'='Camel', '3'='Newport', '4'='Kool', '5'='Winston', '6'='Benson and hedges', 
                            '7'='Salem', '8'='Some other brand', '77'='Refused', '99'="Don't know")
UsedInLast5Days     <- list('1'='Cigarettes', '2'='Pipes', '3'='Cigars', '4'='Chewing tobacco', '5' = 'Snuff', 
                            '6'='Nicotine patches, gum, or other nicotine product', '77'='Refused', '99'="Don't know")
WhenLastSmoked      <- list('1'='Today', '2'='Yesterday', '3'='3 to 5 days ago', '7'='Refused', '9'="Don't know")
SmokingQuestionMode <- list('1'='A-CASI B(12 Yrs.-19 Yrs.)', '2'='MEC CAPI B(20 Yrs.-150 Yrs.)')   
AbilityChange       <- list('1'='Better Now', '2'='Worse Now', '3'='No Change', '7'='Refused', '9'="Don't know")
NoticeAbilityChange <- list('1'='Less than 3 Months Ago', '2'='3 to 12 months (1 year) ago', '3'='1 to 4 years ago', 
                            '4'='5 to 9 years ago', '5'='Ten or more years ago', '7'='Refused', '9'="Don't know")
SmellProblemFreq    <- list('1'='It is always there', '2'='It comes and goes', '3'='I have a problem only with a cold', '7'='Refused', '9'="Don't know")
TasteInMouth        <- list('1'='Sweet', '2'='Sour', '3'='Salty','4'='Bitter', '5'='Metallic', '6'='Burning or Tingling',
                            '7'='Bad or Foul', '8'='Something else', '77'='Refused', '99'="Don't know")
WhenLastDiscussed   <- list('1'='In the Past 12 Months', '2'='1 to 4 Years Ago', '3'='5 to 9 years ago', '4'='Ten or more years ago', '7'='Refused', '9'="Don't know")
TuberculosisTest    <- list('1'='Skin test', '2'='Blood test', '3'='Tine test', '7'='Refused', '9'="Don't know")
ConsiderWeight      <- list('1'='Overweight', '2'='Underweight', '3'='About the right weight', '7'='Refused', '9'="Don't know")
WishToChangeWt      <- list('1'='More', '2'='Less', '3'='Stay about the same', '7'='Refused', '9'="Don't know")
WishToChangeWt2     <- list('1'='Lose weight', '2'='Gain weight', '3'='Stay the same weight', '4'='Not trying to do anything about your weight', '7'='Refused', '9'="Don't know")
weightLossPlan      <- list('10'='Ate less food (amount)', '11'='Switched to foods with lower calories', '12'='Ate less fat', '13'='Exercised', '14'='Skipped meals', 
                            '15'="Ate 'diet' foods or products", '16'='Used a liquid diet formula such as slimfast or optifast', 
                            '17'='Joined a weight loss program such as Weight Watchers, Jenny Craig, Tops, or Overeaters Anonymous', 
                            '30'='Followed a special diet', '31'='Took diet pills prescribed by a doctor', 
                            '32'='Took other pills, medicines, herbs, or supplements not needing a prescription', '33'='Took laxatives or vomited', 
                            '34'='Drank a lot of water', '40'='Other', '41'='Ate fewer carbohydrates', '42'='Started to smoke or began to smoke again', 
                            '43'='Ate more fruits, vegetables, salads', '44'='Changed eating habits', '45'='Ate less sugar, candy, sweets', 
                            '46'='Ate less junk food or fast food', '77'='Refused', '99'="Don't know")
HealthSpecialist    <- list('1'='Personal trainer', '2'='Dietitian', '3'='Nutritionist', '4'='Doctor', 
                            '5'='Other health professional', '7'='Refused', '9'="Don't know")
ReasonToChangeWt    <- list('10'='I want to look better', '11'='I want to be healthier', '12'='I want to be better at sports and other physical activities', 
                            '13'='I get teased about my weight', '14'='I think my clothes will fit better', '15'='I think boys will like me better', 
                            '16'='I think girls will like me better', '17'='My friends are trying to lose weight', 
                            '18'='Someone in my family is trying to lose weight', '19'='My mother or father wants me to lose weight', 
                            '20'='My teacher or coach wants me to lose weight', '21'='A doctor, nurse, or other health professional wants me to lose weight', 
                            '24'='I want to feel good/better about myself', '26'="I want to be skinny / I don't want to be fat / because I'm overweight or obese", 
                            '30'='Other reason', '77'='Refused', '99'="Don't know")
HowOftenOnDiet      <- list('1'='Never', '2'='Sometimes', '3'='A lot', '7'='Refused', '9'="Don't know")
OffBalanceReason    <- list('1'='A cold or the flu', '2'='Injuries or accidents', '3'='Use of drugs or medications', '4'='Age or getting older', '5'='Surgery', 
                            '6'='Hearing problems - including ringing in the ears', '7'='Vision or seeing problems', '8'='None', '77'='Refused', '99'="Don't know")
HealthStatusSource  <- list('1'='Dietary Recall Component -- B(1-11)', '2'='MEC CAPI Questionnaire -- B(12-150)')
SkinMoles           <- list('0'='None', '1'='1 or 2', '2'='3 to 5', '3'='6 to 10', '4'='More than 10', '7'='Refused', '9'="Don't know")
NaturalHairColor    <- list('1'='Red', '2'='Blonde', '3'='Light brown', '4'='Medium brown', '5'='Dark brown', '6'='Black', '7'='Other', '77'='Refused', '99'="Don't know")
SkinConditionEffect <- list('10'='Hands', '11'='Arms', '12'='Head, Face, or Neck', '13'='Torso', '14'='Legs', '15'='Shoulder', 
                            '16'='Groin', '17'='Buttocks', '18'='Feet', '30'='Other Body Area', '77'='Refused', '99'="Don't know")
HandsAndFeet        <- list('1'='Hands', '2'='Feet', '3'='Both', '7'='Refused', '9'="Don't know")
TypeOfMilk          <- list('10'='Whole or regular', '11'='2% fat milk (includes "low fat milk" not further specified)', '12'='1% fat milk', 
                            '13'='Skim, nonfat, or 0.5% fat milk (includes liquid or reconstituted from dry)', '30'='Another type', '77'='Refused', '99'="Don't know")
MilkConsumed        <- list('0'='Never', '1'='Rarely-less than once a week', '2'='Sometimes-once a week or more, but less than once a day', '3'='Often-once a day or more', '4'='Varied', '7'='Refused', '9'="Don't know")
RelativeWithDisease <- list('1'='Mother', '2'='Father', '3'="Mother's mother", '4'="Mother's father", '5'="Father's mother", '6'="Father's father", '7'='Brother', '8'='Sister', '9'='Other', '77'='Refused', '99'="Don't know")
OneTwoOrMore        <- list('1'='One time only', '2'='Two or more times')
DayWeekMonth        <- list('1'='Day', '2'='Week', '3'='Month', '7'='Refused', '9'="Don't know")
ActivityLevel       <- list('1'='More active', '2'='Less active', '3'='About the same', '7'='Refused', '9'="Don't know")

nhanesCodeMapQuestionnaire <- list()
nhanesCodeMapQuestionnaire[['ACD010A']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACD010B']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACD010C']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACD011A']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACD011B']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACD011C']]     <- 'Language'
nhanesCodeMapQuestionnaire[['ACQ020']]      <- 'SpanishEnglish'
nhanesCodeMapQuestionnaire[['ACQ030']]      <- 'SpanishEnglish'
nhanesCodeMapQuestionnaire[['ACD040']]      <- 'SpanishEnglish'
nhanesCodeMapQuestionnaire[['ACQ050']]      <- 'SpanishEnglish'
nhanesCodeMapQuestionnaire[['ACQ060']]      <- 'SpanishEnglish'
nhanesCodeMapQuestionnaire[['ACD110']]      <- 'AsianEnglish'
nhanesCodeMapQuestionnaire[['ALQ010']]      <- 'AgeOfFirstDrink'
nhanesCodeMapQuestionnaire[['ALD020']]      <- 'DaysDrankLifetime'
nhanesCodeMapQuestionnaire[['ALD030']]      <- 'DaysDrank30days'
nhanesCodeMapQuestionnaire[['ALD040']]      <- 'DaysDrank5orMore30'
nhanesCodeMapQuestionnaire[['ALQ101']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ALQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ALQ120U']]     <- 'Duration'
nhanesCodeMapQuestionnaire[['ALQ140U']]     <- 'Duration'
nhanesCodeMapQuestionnaire[['ALQ141U']]     <- 'Duration'
nhanesCodeMapQuestionnaire[['ALQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ALQ151']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ080A']]     <- 'Pet'
nhanesCodeMapQuestionnaire[['AGQ080B']]     <- 'Pet'
nhanesCodeMapQuestionnaire[['AGQ080C']]     <- 'Pet'
nhanesCodeMapQuestionnaire[['AGQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ110A']]     <- 'Season'
nhanesCodeMapQuestionnaire[['AGQ110B']]     <- 'Season'
nhanesCodeMapQuestionnaire[['AGQ110C']]     <- 'Season'
nhanesCodeMapQuestionnaire[['AGQ110D']]     <- 'Season'
nhanesCodeMapQuestionnaire[['AGQ120']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ130']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ180']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AA']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AB']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AC']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AD']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AE']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AF']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ022AG']]    <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ024G']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ030A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ030B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ030C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ030D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ030E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ077']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARD125A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARD130A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ125C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ125D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ125E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ135C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ARQ135D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ054']]      <- 'HearingQuality'
nhanesCodeMapQuestionnaire[['AUQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ100']]      <- 'HowOften2'
nhanesCodeMapQuestionnaire[['AUQ110']]      <- 'HowOften2'
nhanesCodeMapQuestionnaire[['AUQ130']]      <- 'HearingQuality2'
nhanesCodeMapQuestionnaire[['AUQ131']]      <- 'HearingQuality'
nhanesCodeMapQuestionnaire[['AUQ136']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ138']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ140']]      <- 'EventTime1'
nhanesCodeMapQuestionnaire[['AUQ141']]      <- 'EventTime'
nhanesCodeMapQuestionnaire[['AUQ144']]      <- 'EventTime'
nhanesCodeMapQuestionnaire[['AUQ146']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ152']]      <- 'HowOften2'
nhanesCodeMapQuestionnaire[['AUQ154']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ170']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ171']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ180']]      <- 'HowOften3'
nhanesCodeMapQuestionnaire[['AUQ185']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ190']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ191']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ220']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ230']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ240']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ250']]      <- 'EventTime2'
nhanesCodeMapQuestionnaire[['AUQ255']]      <- 'HowOften3'
nhanesCodeMapQuestionnaire[['AUQ260']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ270']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ280']]      <- 'Severity'
nhanesCodeMapQuestionnaire[['AUQ290']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ300']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ310']]      <- 'RoundsFired'
nhanesCodeMapQuestionnaire[['AUQ320']]      <- 'HowOften2'
nhanesCodeMapQuestionnaire[['AUQ330']]      <- 'YesNoNeverWork'
nhanesCodeMapQuestionnaire[['AUQ340']]      <- 'HowLong'
nhanesCodeMapQuestionnaire[['AUQ350']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ360']]      <- 'HowLong'
nhanesCodeMapQuestionnaire[['AUQ370']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ380']]      <- 'HowOften2'
nhanesCodeMapQuestionnaire[['AUQ211']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ231']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AUQ241']]      <- 'HowOften'
nhanesCodeMapQuestionnaire[['AUD148']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ020A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ020B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ020C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ030A']]     <- 'HowLongProblem'
nhanesCodeMapQuestionnaire[['BAQ030B']]     <- 'HowLongProblem'
nhanesCodeMapQuestionnaire[['BAQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ060A']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060B']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060C']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060D']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060E']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060F']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060G']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ060H']]     <- 'OffBalanceReason'
nhanesCodeMapQuestionnaire[['BAQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ075']]      <- 'HowLongAgoTreated'
nhanesCodeMapQuestionnaire[['BAQ080A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ080B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ080C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ080D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BAQ090']]      <- 'Comparison'
nhanesCodeMapQuestionnaire[['BAQ100']]      <- 'YesNoRefused'

nhanesCodeMapQuestionnaire[['BPQ010']]      <- 'TimeSinceBPReading'
nhanesCodeMapQuestionnaire[['BPQ020']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ040F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ050A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ050B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ050C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ050D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ050E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ056']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ057']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ059']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ070']]      <- 'EventTime3'
nhanesCodeMapQuestionnaire[['BPQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ090A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ090B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ090C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ090D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ100A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ100B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ100C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ100D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ110A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ110B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ110C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ120']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ130']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['BPQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CDQ001']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CDQ002']]      <- 'YesNoNeverWalk'
nhanesCodeMapQuestionnaire[['CDQ003']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CDQ004']]      <- 'ChangeOfPace'
nhanesCodeMapQuestionnaire[['CDQ005']]      <- 'Relieved'
nhanesCodeMapQuestionnaire[['CDQ006']]      <- 'ReliefTime'
nhanesCodeMapQuestionnaire[['CDQ008']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CDQ009A']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009B']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009C']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009D']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009E']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009F']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009G']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ009H']]     <- 'PainLocation'
nhanesCodeMapQuestionnaire[['CDQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ020']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CKQ070U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DBQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DBQ071A']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ071B']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ071C']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ071D']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ071U']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBD197']]      <- 'MilkConsumed'
nhanesCodeMapQuestionnaire[['DBQ221A']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ221B']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ221C']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ221D']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBQ221U']]     <- 'TypeOfMilk'
nhanesCodeMapQuestionnaire[['DBD235A']]     <- 'MilkConsumed'
nhanesCodeMapQuestionnaire[['DBD235B']]     <- 'MilkConsumed'
nhanesCodeMapQuestionnaire[['DBD235C']]     <- 'MilkConsumed'
nhanesCodeMapQuestionnaire[['DBQ301']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DBQ330']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DBQ360']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DBQ370']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DBQ400']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DPQ010']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ020']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ030']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ040']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ050']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ060']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ070']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ080']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ090']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DPQ100']]      <- 'Frequency'
nhanesCodeMapQuestionnaire[['DED011']]      <- 'SkinMoles'
nhanesCodeMapQuestionnaire[['DED021']]      <- 'NaturalHairColor'
nhanesCodeMapQuestionnaire[['DED031']]      <- 'SkinReaction'
nhanesCodeMapQuestionnaire[['DEQ034A']]     <- 'Frequency2'
nhanesCodeMapQuestionnaire[['DEQ034B']]     <- 'Frequency2'
nhanesCodeMapQuestionnaire[['DEQ034C']]     <- 'Frequency2'
nhanesCodeMapQuestionnaire[['DEQ034D']]     <- 'Frequency2'
nhanesCodeMapQuestionnaire[['DED051']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DEQ053']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DED061']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DED071']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DEQ083A']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083B']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083C']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083D']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083E']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083F']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083G']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083H']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DEQ083I']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DED083U']]     <- 'SkinConditionEffect'
nhanesCodeMapQuestionnaire[['DIQ010']]      <- 'YesNoBrdrline'
nhanesCodeMapQuestionnaire[['DIQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ060U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['DIQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ110']]      <- 'HandsAndFeet'
nhanesCodeMapQuestionnaire[['DIQ120']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ130']]      <- 'HandsAndFeet'
nhanesCodeMapQuestionnaire[['DIQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ170']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ172']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ230']]      <- 'EventTime4'
nhanesCodeMapQuestionnaire[['DIQ240']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ260U']]     <- 'Frequency3'
nhanesCodeMapQuestionnaire[['DIQ275']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DIQ291']]      <- 'A1Clevel'
nhanesCodeMapQuestionnaire[['DIQ350U']]     <- 'Frequency3'
nhanesCodeMapQuestionnaire[['DIQ360']]      <- 'LastDilation'
nhanesCodeMapQuestionnaire[['DIQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ120']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ200']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ211']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ215U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ217']]      <- 'HowOftenPerMo'
nhanesCodeMapQuestionnaire[['DUQ219']]      <- 'HowManyPerDay'
nhanesCodeMapQuestionnaire[['DUQ220U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ240']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ250']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ270U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ272']]      <- 'HowManyInLife'
nhanesCodeMapQuestionnaire[['DUQ290']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ310U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ330']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ350U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ352']]      <- 'HowManyInLife'
nhanesCodeMapQuestionnaire[['DUQ370']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['DUQ380A']]     <- 'DrugsInjected'
nhanesCodeMapQuestionnaire[['DUQ380B']]     <- 'DrugsInjected'
nhanesCodeMapQuestionnaire[['DUQ380C']]     <- 'DrugsInjected'
nhanesCodeMapQuestionnaire[['DUQ380D']]     <- 'DrugsInjected'
nhanesCodeMapQuestionnaire[['DUQ380E']]     <- 'DrugsInjected'
nhanesCodeMapQuestionnaire[['DUQ400U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['DUQ410']]      <- 'HowManyInLife'
nhanesCodeMapQuestionnaire[['DUQ420']]      <- 'HowOftenInject'
nhanesCodeMapQuestionnaire[['DUQ430']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ020']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ080']]      <- 'BirthWeight5p5'
nhanesCodeMapQuestionnaire[['ECQ090']]      <- 'BirthWeight9'
nhanesCodeMapQuestionnaire[['ECQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ121']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ162']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ170']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD180']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD200']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ400']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ420']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ440']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ450']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ470']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ480']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ490']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ500']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSQ520']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD650C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD650M']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD660M']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['FSD660C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ080E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['ECQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ121']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ124']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ126A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ126B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ126C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ126D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ126E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ130']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ140A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ140B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ140C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ140D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ140E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HCQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HIQ011']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID030A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID030B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID030C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID030D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HID030E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HIQ031A']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031B']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031C']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031D']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031E']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031F']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031G']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031H']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031I']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031J']]     <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HIQ031AA']]    <- 'HealthInsure'
nhanesCodeMapQuestionnaire[['HID040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HIQ260']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HIQ105']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['HIQ270']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HIQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOQ065']]      <- 'HomeOwnOrRent'
nhanesCodeMapQuestionnaire[['HOQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD170']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD190']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HOD220']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSD010']]      <- 'Condition'
nhanesCodeMapQuestionnaire[['HSQ500']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSQ510']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSQ520']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSQ571']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSQ590']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HSAQUEX']]     <- 'HealthStatusSource'
nhanesCodeMapQuestionnaire[['HUQ010']]      <- 'Condition'
nhanesCodeMapQuestionnaire[['HUQ020']]      <- 'Comparison'
nhanesCodeMapQuestionnaire[['HUQ030']]      <- 'RoutinePlace'
nhanesCodeMapQuestionnaire[['HUQ040']]      <- 'CareVisitPlace'
nhanesCodeMapQuestionnaire[['HUQ050']]      <- 'TimeSinceVisit'
nhanesCodeMapQuestionnaire[['HUQ060']]      <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['HUQ071']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HUQ082']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HUQ086']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['HUQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['IMQ011']]      <- 'HepAVaccine'
nhanesCodeMapQuestionnaire[['IMQ020']]      <- 'HepBVaccine'
nhanesCodeMapQuestionnaire[['IMQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['IMQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['IMQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['IMQ080']]      <- 'HPVVaccine'
nhanesCodeMapQuestionnaire[['IMQ045']]      <- 'DosesReceived'
nhanesCodeMapQuestionnaire[['KIQ022']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ025']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ026']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ005']]      <- 'LeakageFreq'
nhanesCodeMapQuestionnaire[['KIQ010']]      <- 'UrineLoss'
nhanesCodeMapQuestionnaire[['KIQ042']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ430']]      <- 'Frequency4'
nhanesCodeMapQuestionnaire[['KIQ044']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ450']]      <- 'Frequency4'
nhanesCodeMapQuestionnaire[['KIQ046']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ470']]      <- 'Frequency4'
nhanesCodeMapQuestionnaire[['KIQ050']]      <- 'BotheredBy'
nhanesCodeMapQuestionnaire[['KIQ052']]      <- 'BotheredBy'
nhanesCodeMapQuestionnaire[['KIQ081']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ101']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ106']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ121']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ141']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ182']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ321']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ341']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ361']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['KIQ381']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ035']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ051']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ053']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ082']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ083']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ084']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ086']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ092']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ114']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ120A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ120B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ120C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ120D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ149']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160G']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160J']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160K']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160L']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160M']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170K']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170L']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170M']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ195']]      <- 'ArthritisType'
nhanesCodeMapQuestionnaire[['MCQ160n']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160b']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160c']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160d']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160e']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160f']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160g']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160m']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170m']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160k']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170k']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ160l']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ170l']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ220']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ230a']]     <- 'KindOfCancer'
nhanesCodeMapQuestionnaire[['MCQ230b']]     <- 'KindOfCancer'
nhanesCodeMapQuestionnaire[['MCQ230c']]     <- 'KindOfCancer'
nhanesCodeMapQuestionnaire[['MCQ230d']]     <- 'KindOfCancer'
nhanesCodeMapQuestionnaire[['MCQ250A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ250B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ250C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ250E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ250F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ250G']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ260AA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AD']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260AI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BD']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260BI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CD']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260CI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260ED']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260EI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FD']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260FI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GA']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GB']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GC']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GD']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GE']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GF']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GG']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GH']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ260GI']]    <- 'RelativeWithDisease'
nhanesCodeMapQuestionnaire[['MCQ265']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ270']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ300a']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ300b']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ300c']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ365a']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ365b']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ365c']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ365d']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ370a']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ370b']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ370c']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ370d']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['MCQ380']]      <- 'RememberFreq'
nhanesCodeMapQuestionnaire[['OCD150']]      <- 'WorkStatus'
nhanesCodeMapQuestionnaire[['OCQ200']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ260']]      <- 'WorkSituation'
nhanesCodeMapQuestionnaire[['OCQ275']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ295']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ340']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ350']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ380']]      <- 'NotWorkReason'
nhanesCodeMapQuestionnaire[['OCQ420']]      <- 'NotWorkReason'
nhanesCodeMapQuestionnaire[['OCQ430']]      <- 'NotWorkReason'
nhanesCodeMapQuestionnaire[['OCQ450']]      <- 'NotWorkReason'
nhanesCodeMapQuestionnaire[['OCQ510']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ530']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ550']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OCQ570']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ030']]      <- 'DentalVisit'
nhanesCodeMapQuestionnaire[['OHQ033']]      <- 'DentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ115']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ691']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ700']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ770']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ780A']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780B']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780C']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780D']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780E']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780F']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780G']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780H']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780I']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780J']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ780K']]     <- 'NoDentalVisitReason'
nhanesCodeMapQuestionnaire[['OHQ610']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ612']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ614']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ620']]      <- 'DentalComplaints'
nhanesCodeMapQuestionnaire[['OHQ640']]      <- 'DentalComplaints'
nhanesCodeMapQuestionnaire[['OHQ680']]      <- 'DentalComplaints'
nhanesCodeMapQuestionnaire[['OHD721']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHD730']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHD740']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHD750']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ770']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ835']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ845']]      <- 'Condition'
nhanesCodeMapQuestionnaire[['OHQ850']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ855']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ860']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ865']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ880']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ885']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OHQ895']]      <- 'OralCancerExam'
nhanesCodeMapQuestionnaire[['OHQ900']]      <- 'OralExamPro'
nhanesCodeMapQuestionnaire[['OSQ010a']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OSQ010b']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OSQ010c']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OSQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['OSQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PUD021']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD031']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD032']]      <- 'OneTwoOrMore'
nhanesCodeMapQuestionnaire[['PUD033']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD034']]      <- 'OneTwoOrMore'
nhanesCodeMapQuestionnaire[['PUD041']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD061']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD071']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD072']]      <- 'OneTwoOrMore'
nhanesCodeMapQuestionnaire[['PUD073']]      <- 'YesNo'
nhanesCodeMapQuestionnaire[['PUD074']]      <- 'OneTwoOrMore'
nhanesCodeMapQuestionnaire[['PUQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PUQ110']]      <- 'YesNoRefused'

nhanesCodeMapQuestionnaire[['PAD020']]      <- 'YesNoUnable'
nhanesCodeMapQuestionnaire[['PAQ050U']]     <- 'DayWeekMonth'
nhanesCodeMapQuestionnaire[['PAD100']]      <- 'YesNoUnable'
nhanesCodeMapQuestionnaire[['PAD200']]      <- 'YesNoUnable'
nhanesCodeMapQuestionnaire[['PAD320']]      <- 'YesNoUnable'
nhanesCodeMapQuestionnaire[['PAD440']]      <- 'YesNoUnable'
nhanesCodeMapQuestionnaire[['PAQ480']]      <- 'HoursPerDay'
nhanesCodeMapQuestionnaire[['PAQ500']]      <- 'ActivityLevel'
nhanesCodeMapQuestionnaire[['PAQ520']]      <- 'ActivityLevel'
nhanesCodeMapQuestionnaire[['PAQ540']]      <- 'ActivityLevel'
nhanesCodeMapQuestionnaire[['PAD570']]      <- 'ActivityLevel'
nhanesCodeMapQuestionnaire[['PAQ580']]      <- 'ActivityLevel'
nhanesCodeMapQuestionnaire[['PAD590']]      <- 'HoursPerDay'
nhanesCodeMapQuestionnaire[['PAD600']]      <- 'HoursPerDay'

nhanesCodeMapQuestionnaire[['PAQ605']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PAQ620']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PAQ635']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PAQ650']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PAQ665']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PAQ710']]      <- 'HoursPerDay'
nhanesCodeMapQuestionnaire[['PAQ715']]      <- 'HoursPerDay'
nhanesCodeMapQuestionnaire[['PFQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ015']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ020']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ041']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ049']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ051']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ054']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ057']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ059']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PFQ061A']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061B']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061C']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061D']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061E']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061F']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061G']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061H']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061I']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061J']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061K']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061L']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061M']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061N']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061O']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061P']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061Q']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061R']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061S']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ061T']]     <- 'Difficulty'
nhanesCodeMapQuestionnaire[['PFQ063A']]     <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['PFQ063B']]     <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['PFQ063C']]     <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['PFQ063D']]     <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['PFQ063E']]     <- 'HealthProblems'
nhanesCodeMapQuestionnaire[['PFQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ030F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ090F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ100F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ120']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ130A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ130B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ130C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ130D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ130E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ150']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ170A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ170B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ170C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ170D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ180']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ190']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['PSQ200G']]     <- 'YesNoRefused'

nhanesCodeMapQuestionnaire[['RXDUSE']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RXQSEEN']]     <- 'YesNo'
nhanesCodeMapQuestionnaire[['RXD300']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RXD330']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RXQ510']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RXQ515']]      <- 'AspirinAdvice'
nhanesCodeMapQuestionnaire[['RXQ520']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RXQ525G']]     <- 'PillSchedule'
nhanesCodeMapQuestionnaire[['RXQ525U']]     <- 'DoseFrequency'
nhanesCodeMapQuestionnaire[['RHQ020']]      <- 'AgeOfMenarche'
nhanesCodeMapQuestionnaire[['RHQ031']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHD042']]      <- 'NonRegPeriod'
nhanesCodeMapQuestionnaire[['RHQ070']]      <- 'AgeLastPeriod'
nhanesCodeMapQuestionnaire[['RHQ131']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHD143']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ162']]      <- 'PregDiabetes'
nhanesCodeMapQuestionnaire[['RHQ172']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ200']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ205']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ250']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHD280']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ300']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ305']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ360']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ380']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ395']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ420']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHD442']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ460U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ510']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ520']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ540']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ541A']]     <- 'HormonePills'
nhanesCodeMapQuestionnaire[['RHQ541B']]     <- 'HormonePatches'
nhanesCodeMapQuestionnaire[['RHQ541C']]     <- 'HormoneCream'
nhanesCodeMapQuestionnaire[['RHQ554']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ558']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ560U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ562']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ566']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ568U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ570']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ574']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ576U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ580']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ584']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ586U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ596']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ600']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ602U']]     <- 'TimeUnits'
nhanesCodeMapQuestionnaire[['RHQ700']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ720']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RHQ740']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ031']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ090']]      <- 'WheezingPerWeek'
nhanesCodeMapQuestionnaire[['RDQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ134']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['RDQ135']]      <- 'LimitedByWheezing'
nhanesCodeMapQuestionnaire[['RDQ137']]      <- 'DaysLostToWheezing'
nhanesCodeMapQuestionnaire[['RDQ140']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['AGQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXD021']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ800']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ803']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ806']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ809']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ700']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ703']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ706']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ709']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ853']]      <- 'YesNoRefused'

nhanesCodeMapQuestionnaire[['SXQ645']]      <- 'OralSexProtection'
nhanesCodeMapQuestionnaire[['SXQ648']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ610']]      <- 'VaginalOrAnalSex'
nhanesCodeMapQuestionnaire[['SXQ251']]      <- 'SexWithCondom'
nhanesCodeMapQuestionnaire[['SXQ741']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ753']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ260']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ265']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ270']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ272']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SXQ280']]      <- 'Circumcised'
nhanesCodeMapQuestionnaire[['SXQ292']]      <- 'MSexOrientation'
nhanesCodeMapQuestionnaire[['SXQ294']]      <- 'FSexOrientation'
nhanesCodeMapQuestionnaire[['SLQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SLQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SMQ020']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SMQ040']]      <- 'SmokingPattern'
nhanesCodeMapQuestionnaire[['SMQ050U']]     <- 'HowLong2'
nhanesCodeMapQuestionnaire[['SMQ077']]      <- 'SmokeAfterWaking'
nhanesCodeMapQuestionnaire[['SMD093']]      <- 'YesNoCigarettes'
nhanesCodeMapQuestionnaire[['SMD100FL']]    <- 'CigaretteFilter'
nhanesCodeMapQuestionnaire[['SMD100MN']]    <- 'MentholIndicator'
nhanesCodeMapQuestionnaire[['SMD100LN']]    <- 'CigaretteLength'
nhanesCodeMapQuestionnaire[['SMQ670']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SMD410']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SMQ680']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['SMQ690A']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ690B']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ690C']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ690D']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ690E']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ690F']]     <- 'UsedInLast5Days'
nhanesCodeMapQuestionnaire[['SMQ725']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMQ755']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMQ785']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMQ815']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMQ819']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMQ840']]      <- 'WhenLastSmoked'
nhanesCodeMapQuestionnaire[['SMAQUEX']]     <- 'SmokingQuestionMode'
nhanesCodeMapQuestionnaire[['CSQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ020']]      <- 'AbilityChange'
nhanesCodeMapQuestionnaire[['CSQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ060']]      <- 'NoticeAbilityChange'
nhanesCodeMapQuestionnaire[['CSQ070']]      <- 'SmellProblemFreq'
nhanesCodeMapQuestionnaire[['CSQ080']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ090A']]     <- 'AbilityChange'
nhanesCodeMapQuestionnaire[['CSQ090B']]     <- 'AbilityChange'
nhanesCodeMapQuestionnaire[['CSQ090C']]     <- 'AbilityChange'
nhanesCodeMapQuestionnaire[['CSQ090D']]     <- 'AbilityChange'
nhanesCodeMapQuestionnaire[['CSQ100']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ110']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120A']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120B']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120C']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120D']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120E']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120F']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120G']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ120H']]     <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ140']]      <- 'NoticeAbilityChange'
nhanesCodeMapQuestionnaire[['CSQ160']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ170']]      <- 'WhenLastDiscussed'
nhanesCodeMapQuestionnaire[['CSQ180']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ190']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ200']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ202']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ204']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ220']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ240']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ250']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['CSQ260']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ010']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ015a']]     <- 'TuberculosisTest'
nhanesCodeMapQuestionnaire[['TBQ015b']]     <- 'TuberculosisTest'
nhanesCodeMapQuestionnaire[['TBQ015c']]     <- 'TuberculosisTest'
nhanesCodeMapQuestionnaire[['TBQ022']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ025']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ028']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ030']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ035']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ040']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ050']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['TBQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHQ030']]      <- 'ConsiderWeight'
nhanesCodeMapQuestionnaire[['WHQ040']]      <- 'WishToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ060']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHQ070']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHD080A']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080B']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080C']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080D']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080E']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080F']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080G']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080H']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080I']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080J']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080K']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080L']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080M']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080N']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080O']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080P']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080Q']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080R']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080S']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD080T']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHQ270']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHQ280A']]     <- 'HealthSpecialist'
nhanesCodeMapQuestionnaire[['WHQ280B']]     <- 'HealthSpecialist'
nhanesCodeMapQuestionnaire[['WHQ280C']]     <- 'HealthSpecialist'
nhanesCodeMapQuestionnaire[['WHQ280D']]     <- 'HealthSpecialist'
nhanesCodeMapQuestionnaire[['WHQ280E']]     <- 'HealthSpecialist'
nhanesCodeMapQuestionnaire[['WHQ090']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHD100A']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100B']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100C']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100D']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100E']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100F']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100G']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100H']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100I']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100J']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100K']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100L']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100M']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100N']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100O']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100P']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100Q']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100R']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100S']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHD100T']]     <- 'WeightLossPlan'
nhanesCodeMapQuestionnaire[['WHQ210']]      <- 'YesNoRefused'
nhanesCodeMapQuestionnaire[['WHQ030M']]     <- 'ConsiderWeight'
nhanesCodeMapQuestionnaire[['WHQ500']]      <- 'WishToChangeWt2'
nhanesCodeMapQuestionnaire[['WHQ510A']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510B']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510C']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510D']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510E']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510F']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510G']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510H']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510I']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510J']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510K']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510L']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510N']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510P']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ510U']]     <- 'ReasonToChangeWt'
nhanesCodeMapQuestionnaire[['WHQ530']]      <- 'HowOftenOnDiet'
nhanesCodeMapQuestionnaire[['WHQ540']]      <- 'HowOftenOnDiet'
nhanesCodeMapQuestionnaire[['WHQ550']]      <- 'HowOftenOnDiet'
nhanesCodeMapQuestionnaire[['WHQ560']]      <- 'HowOftenOnDiet'
nhanesCodeMapQuestionnaire[['WHQ570']]      <- 'HowOftenOnDiet'
nhanesCodeMapQuestionnaire[['WHQ580']]      <- 'HowOftenOnDiet'



