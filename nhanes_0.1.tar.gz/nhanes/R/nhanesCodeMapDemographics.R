## nhanesCodeMapDemographics

InterviewStatus <- list('1'='Interviewed Only','2'='Both Interviewed and MEC examined')
InterviewPeriod <- list('1'='November 1 through April 30','2'='May 1 through October 31')
Gender          <- list('1'='Male', '2'='Female')
Ethnicity1      <- list('1'='Mexican American','2'='Other Hispanic','3'='Non-Hispanic White', 
                        '4'='Non-Hispanic Black', '5'='Other Race/Multiracial')
Ethnicity2      <- list('1'='Non-Hispanic White','2'='Non-Hispanic Black','3'='Mexican American',
                        '4'='Other Race/Multiracial', '5'='Other Hispanic')
Ethnicity3      <- list('1'='Mexican American','2'='Other Hispanic','3'='Non-Hispanic White',
                        '4'='Non-Hispanic Black', '5'='Non-Hispanic Asian', '6'='Other Race/Multiracial')
YesNoRefused    <- list('1'='Yes', '2'='No', '7'='Refused', '9'="Don't know")
Birthplace1     <- list('1'='Born in 50 US States or Washington, DC','2'='Born in Mexico',
                        '3'='Born Elsewhere','7'='Refused','9'="Don't know")
Birthplace2     <- list('1'='Born in 50 US States or Washington, DC','2'='Born in Mexico','4'='Born in Other Spanish Speaking Country',
                        '5'='Born in Other Non-Spanish Speaking Country','7'= 'Refused', '9'="Don't know")
Birthplace4     <- list('1'='Born in 50 US States or Washington, DC','2'='Others', '7'='Refused','9'="Don't know")
Citizen         <- list('1'='Citizen by birth or naturalization', '2'='Not a citizen of the US', '7'='Refused','9'="Don't know")
YearsInUS       <- list('1'='Less than 1 year','2'='1 yr., less than 5 yrs.','3'='5 yrs., less than 10 yrs.',
                        '4'='10 yrs., less than 15 yrs.','5'='15 yrs., less than 20 yrs.','6'='20 yrs., less than 30 yrs.',
                        '7'='30 yrs., less than 40 yrs.','8'='40 yrs., less than 50 yrs.','9'='50 years or more',
                        '77'='Refused','88'='Could not determine','99'="Don't know")
Education1      <- list('1'='Less Than High School','2'='High School Diploma (including GED)',
                        '3'='More Than High School','7'='Refused','9'="Don't know")
Education2      <- list('1'='Less Than 9th Grade','2'='9-11th Grade (Includes 12th grade with no diploma)',
                        '3'='High School Grad/GED or Equivalent','4'='Some College or AA degree', 
                        '5'='College Graduate or above','7'='Refused','9'="Don't know")
Education3      <- list('0'='Never Attended / Kindergarten Only','1'='1st Grade','2'='2nd Grade','3'='3rd Grade',
                        '4'='4th Grade','5'='5th Grade','6'='6th Grade','7'='7th Grade','8'='8th Grade',
                        '9'='9th Grade','10'='10th Grade','11'='11th Grade','12'='12th Grade, No Diploma',
                        '13'='High School Graduate','14'='GED or Equivalent','15'='More than high school',
                        '55'='Less Than 5th Grade','66'='Less Than 9th Grade','77'='Refused','99'="Don't know")
SchoolStatus    <- list('1'='In school','2'='On vacation from school (between grades)',
                        '3'='Neither in school or on vacation from school (between grades)','7'='Refused','9'="Don't know")
MaritalStatus   <- list('1'='Married','2'='Widowed','3'='Divorced','4'='Separated','5'='Never married',
                        '6'='Living with partner','77'='Refused','99'="Don't know")
Income1         <- list('1'='$0 to $4,999','2'='$5,000 to $9,999','3'='$10,000 to $14,999','4'='$15,000 to $19,999',
                        '5'='$20,000 to $24,999', '6'='$25,000 to $34,999','7'='$35,000 to $44,999',
                        '8'='$45,000 to $54,999', '9'='$55,000 to $64,999','10'='$65,000 to $74,999',
                        '11'='$75,000 and Over','12'='Over $20,000','13'='Under $20,000','77'='Refused','99'="Don't know")
Income2         <- list('1'='$0 to $4,999','2'='$5,000 to $9,999','3'='$10,000 to $14,999','4'='$15,000 to $19,999',
                        '5'='$20,000 to $24,999', '6'='$25,000 to $34,999','7'='$35,000 to $44,999',
                        '8'='$45,000 to $54,999', '9'='$55,000 to $64,999','10'='$65,000 to $74,999',
                        '11'='$75,000 and Over','12'='$20,000 and Over','13'='Under $20,000',
                        '14'='$75,000 to $99,999', '15'= '$100,000 and Over', '77'='Refused', '99'="Don't know")
PregnancyExam   <- list('1'='Yes, positive lab pregnancy test or self-reported pregnant at exam',
                        '2'='SP not pregnant at exam','3'='Cannot ascertain if SP is pregnant at exam')
Pregnancy       <- list('1'='Yes, based on positive lab pregnancy test, self-reported pregnancy status, screener interview data or menstrual period history',
                        '2'='SP not pregnant', '3'='Cannot ascertain if SP is pregnant')
Language        <- list('1'='English', '2'='Spanish')
LanguageA       <- list('1'='English', '2'='Spanish', '3'='Asian languages')
YesNo           <- list('1'='Yes', '2'='No')

nhanesCodeMapDemographics <- list()
nhanesCodeMapDemographics[['DMQMILIT']] <- 'YesNoRefused'
nhanesCodeMapDemographics[['DMQMILIZ']] <- 'YesNoRefused'
nhanesCodeMapDemographics[['DMQADFC']]  <- 'YesNoRefused'
nhanesCodeMapDemographics[['DMDBORN']]  <- 'Birthplace1'
nhanesCodeMapDemographics[['DMDBORN2']] <- 'Birthplace2'
nhanesCodeMapDemographics[['DMDBORN4']] <- 'Birthplace4'
nhanesCodeMapDemographics[['DMDCITZN']] <- 'Citizen'
nhanesCodeMapDemographics[['DMDYRSUS']] <- 'YearsInUS'
nhanesCodeMapDemographics[['DMDEDUC']]  <- 'Education1'
nhanesCodeMapDemographics[['DMDEDUC2']] <- 'Education2'
nhanesCodeMapDemographics[['DMDEDUC3']] <- 'Education3'
nhanesCodeMapDemographics[['DMDSCHOL']] <- 'SchoolStatus'
nhanesCodeMapDemographics[['DMDMARTL']] <- 'MaritalStatus'
nhanesCodeMapDemographics[['INDHHINC']] <- 'Income1'
nhanesCodeMapDemographics[['INDHHIN2']] <- 'Income2'
nhanesCodeMapDemographics[['INDFMINC']] <- 'Income1'
nhanesCodeMapDemographics[['INDFMIN2']] <- 'Income2'
nhanesCodeMapDemographics[['DMDHRGND']] <- 'Gender'
nhanesCodeMapDemographics[['DMDHRBRN']] <- 'Birthplace1'
nhanesCodeMapDemographics[['DMDHRBR2']] <- 'Birthplace2'
nhanesCodeMapDemographics[['DMDHRBR4']] <- 'Birthplace4'
nhanesCodeMapDemographics[['DMDHREDU']] <- 'Education2'
nhanesCodeMapDemographics[['DMDHRMAR']] <- 'MaritalStatus'
nhanesCodeMapDemographics[['DMDHSEDU']] <- 'Education2'
nhanesCodeMapDemographics[['SIALANG']]  <- 'Language'
nhanesCodeMapDemographics[['SIAPROXY']] <- 'YesNo'
nhanesCodeMapDemographics[['SIAINTRP']] <- 'YesNo'
nhanesCodeMapDemographics[['FIALANG']]  <- 'Language'
nhanesCodeMapDemographics[['FIAPROXY']] <- 'YesNo'
nhanesCodeMapDemographics[['FIAINTRP']] <- 'YesNo'
nhanesCodeMapDemographics[['MIALANG']]  <- 'Language'
nhanesCodeMapDemographics[['MIAPROXY']] <- 'YesNo'
nhanesCodeMapDemographics[['MIAINTRP']] <- 'YesNo'
nhanesCodeMapDemographics[['AIALANG']]  <- 'Language'
nhanesCodeMapDemographics[['AIALANGA']] <- 'LanguageA'
nhanesCodeMapDemographics[['RIDEXPRG']] <- 'PregnancyExam'
nhanesCodeMapDemographics[['RIDPREG']]  <- 'Pregnancy'
nhanesCodeMapDemographics[['RIDSTATR']] <- 'InterviewStatus'
nhanesCodeMapDemographics[['RIDEXMON']] <- 'InterviewPeriod'
nhanesCodeMapDemographics[['RIAGENDR']] <- 'Gender'
nhanesCodeMapDemographics[['RIDRETH1']] <- 'Ethnicity1'
nhanesCodeMapDemographics[['RIDRETH2']] <- 'Ethnicity2'
nhanesCodeMapDemographics[['RIDRETH3']] <- 'Ethnicity3'
